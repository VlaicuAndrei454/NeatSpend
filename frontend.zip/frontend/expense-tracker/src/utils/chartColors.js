export const chartColors = [
    '#10b981', // green-500
    '#71717a', // gray-500
    '#000000', // black
    // optional additional accents:
    '#34d399', // green-400
    '#52525b', // gray-600
    '#1a1a1a', // black-light
  ];